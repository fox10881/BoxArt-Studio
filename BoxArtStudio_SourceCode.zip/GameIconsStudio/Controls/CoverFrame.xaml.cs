using System;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Media.Imaging;

namespace GameIconsStudio.Controls;

public sealed partial class CoverFrame
{
    public static readonly DependencyProperty VariantProperty = DependencyProperty.Register(
        nameof(Variant), typeof(CoverVariant), typeof(CoverFrame),
        new PropertyMetadata(CoverVariant.None, (s, _) => ((CoverFrame)s).ApplyVariant()));

    public CoverVariant Variant
    {
        get => (CoverVariant)GetValue(VariantProperty);
        set => SetValue(VariantProperty, value);
    }

    public static readonly DependencyProperty CoverUriProperty = DependencyProperty.Register(
        nameof(CoverUri), typeof(string), typeof(CoverFrame),
        new PropertyMetadata(string.Empty, (s, _) => ((CoverFrame)s).ApplyCover()));

    public string CoverUri
    {
        get => (string)GetValue(CoverUriProperty);
        set => SetValue(CoverUriProperty, value);
    }

    public CoverFrame()
    {
        this.InitializeComponent();
        ApplyVariant();
        ApplyCover();
    }

    private void ApplyVariant()
    {
        if (VariantNone is null) return;
        VariantNone.Visibility = Variant == CoverVariant.None ? Visibility.Visible : Visibility.Collapsed;
        VariantClassicPc.Visibility = Variant == CoverVariant.ClassicPc ? Visibility.Visible : Visibility.Collapsed;
        VariantSteelbook.Visibility = Variant == CoverVariant.Steelbook ? Visibility.Visible : Visibility.Collapsed;
        VariantPlatform.Visibility = Variant == CoverVariant.Platform ? Visibility.Visible : Visibility.Collapsed;
    }

    private void ApplyCover()
    {
        if (ImageNone is null) return;
        var uri = CoverUri;
        var bmp = string.IsNullOrEmpty(uri) ? null : new BitmapImage(new Uri(uri));
        ImageNone.ImageSource = bmp;
        ImageClassicPc.ImageSource = bmp;
        ImageSteelbook.ImageSource = bmp;
        ImagePlatform.ImageSource = bmp;
        if (EmptyOverlay is not null)
            EmptyOverlay.Visibility = bmp is null ? Visibility.Visible : Visibility.Collapsed;
    }
}
