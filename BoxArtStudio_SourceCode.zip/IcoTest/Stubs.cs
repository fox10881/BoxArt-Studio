namespace GameIconsStudio.Services
{
    /// <summary>Harness stub for the in-app log viewer.</summary>
    public static class LogService
    {
        public static void Info(string message) => System.Console.WriteLine($"[log] {message}");
        public static void Warn(string message) => System.Console.WriteLine($"[warn] {message}");
        public static void Error(string message) => System.Console.WriteLine($"[err] {message}");
    }
}

namespace GameIconsStudio
{
    public enum CoverVariant { None, ClassicPc, Steelbook, Platform }

    public class Game
    {
        public string Id { get; set; } = "test";
        public string Name { get; set; } = "Test";
        public string Cover { get; set; } = "";
        public CoverVariant Overlay { get; set; }
        public string ApplyPath { get; set; } = "";
        public bool IsFolderTarget { get; set; }
        public bool StickerPcCdrom { get; set; }
        public bool StickerDvd { get; set; }
        public bool StickerEsrb { get; set; }
        public bool StickerPegi18 { get; set; }
        public bool StickerSeal { get; set; }
    }
}
